The Assignment is coded using Jupiter Notebook since it was most suitable for step by 
step analysis and reporting format.

ipynb file can be opened as follows (assuming anaconda is installed):

1- open a terminal window
2- type 'jupyter notebook' ( that should take the user to browser ui)
3- click on Upload (right upper section) and select the ipynb file

After that point, to reproduce the assignment changing the absolute paths should be sufficient.

If ipynb file doesn't work for some reason, .py version of the same file is also included.
Only difference is the formatting.



